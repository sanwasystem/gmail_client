"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable @typescript-eslint/camelcase */
const env = __importStar(require("./env"));
const AWS = __importStar(require("aws-sdk"));
const toolbox = __importStar(require("aws-toolbox"));
const Types = __importStar(require("./types"));
const gmail_api_client_1 = __importDefault(require("gmail-api-client"));
const dynamo = new AWS.DynamoDB.DocumentClient({ region: env.defaultRegion });
const refreshToken = async () => {
    let failCount = 0;
    const allRecords = await toolbox.dynamo.getAllRecords(dynamo, env.dynamoDbTableName);
    const records = allRecords.filter(Types.isDynamoDBRecord);
    console.log(`DynamoDBから${records.length}件のレコードを取得しました。トークンを更新します`);
    for (const record of records) {
        const credential = record.Data;
        const client = new gmail_api_client_1.default(credential.access_token);
        const newToken = await client
            .refreshAccessToken({
            clientId: credential.client_id,
            clientSecret: credential.client_secret,
            refreshToken: credential.refresh_token
        })
            .catch(reason => {
            console.error(`${record.Account} の更新に失敗しました: ${reason}`);
            failCount++;
        });
        if (typeof newToken === "string") {
            const newRecord = Object.assign({}, record);
            newRecord.Timestamp = new Date().toISOString();
            newRecord.Data.access_token = newToken;
            await dynamo
                .put({
                TableName: env.dynamoDbTableName,
                Item: newRecord
            })
                .promise();
            console.log(`${record.Account}の更新を行いました`);
        }
    }
    if (failCount > 0) {
        return Promise.reject("1件以上のトークン更新が失敗しています");
    }
    return true;
};
exports.default = refreshToken;
//# sourceMappingURL=refreshToken.js.map