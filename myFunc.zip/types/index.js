"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isDynamoDBRecord = (arg) => {
    if (arg === null || typeof arg !== "object") {
        return false;
    }
    if (typeof arg.Account !== "string") {
        return false;
    }
    if (arg.Service !== "Google") {
        return false;
    }
    if (arg.Data === null || typeof arg.Data !== "object") {
        return false;
    }
    if (typeof arg.Data.access_token !== "string") {
        return false;
    }
    if (typeof arg.Data.client_id !== "string") {
        return false;
    }
    if (typeof arg.Data.client_secret !== "string") {
        return false;
    }
    if (typeof arg.Data.refresh_token !== "string") {
        return false;
    }
    if (typeof arg.Data.scope !== "string") {
        return false;
    }
    if (typeof arg.Data.token_type !== "string") {
        return false;
    }
    return true;
};
//# sourceMappingURL=index.js.map