"use strict";
// gmail client
// https://github.com/sanwasystem/gmail_client
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const getClient_1 = __importDefault(require("./getClient"));
const refreshToken_1 = __importDefault(require("./refreshToken"));
exports.handler = async (event) => {
    if (event.action === undefined) {
        // actionが指定されていなかったらトークンを更新する
        return await refreshToken_1.default();
    }
    console.log(event);
    if (event.key !== undefined && typeof event.key !== "string") {
        return Promise.reject("'key' must be undefined or string");
    }
    const client = await getClient_1.default(event.key);
    switch (event.action) {
        case "search":
            return await client.searchMailIds(event.condition);
        case "searchEx":
            return await client.searchMails(event.condition);
        case "addLabels":
            return await client.addLabels(event.messageId, event.labelIds);
        case "allLabels":
            return await client.getLabels();
        case "message":
            return await client.getMailById(event.messageId, event.test);
        case "rawMessage":
            return await client.getRawMailById(event.messageId);
        default:
            return Promise.reject("'action' must be either undefined, 'search', 'searchEx', 'addLabels', 'allLabels', 'rawMessage' or 'message'");
    }
};
//# sourceMappingURL=index.js.map