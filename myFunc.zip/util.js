"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = __importStar(require("aws-sdk"));
const env = __importStar(require("./env"));
AWS.config.update({ region: env.defaultRegion });
const kms = new AWS.KMS();
const decrypt = async (encrypted) => {
    const data = await kms.decrypt({ CiphertextBlob: new Buffer(encrypted, "base64") }).promise();
    const plaintext = data.Plaintext;
    if (!plaintext) {
        throw new Error("failed to decrypt environment variable");
    }
    if (Buffer.isBuffer(plaintext)) {
        return plaintext.toString("ascii");
    }
    return plaintext.toString();
};
exports.decrypt = decrypt;
//# sourceMappingURL=util.js.map