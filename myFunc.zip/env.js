"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = __importStar(require("dotenv"));
dotenv.config();
// 指定した名前の環境変数を返す。定義されていなければ例外をスローする
const getEnv = (name) => {
    const result = process.env[name];
    if (result === undefined) {
        throw new Error(`environment variable "${name}" not defined`);
    }
    return result;
};
const dynamoDbTableName = getEnv("dynamoDbTableName");
exports.dynamoDbTableName = dynamoDbTableName;
const dynamoDbTableKeyName = getEnv("dynamoDbTableKeyName");
exports.dynamoDbTableKeyName = dynamoDbTableKeyName;
const defaultKeyValue = getEnv("defaultKeyValue");
exports.defaultKeyValue = defaultKeyValue;
const defaultRegion = getEnv("defaultRegion");
exports.defaultRegion = defaultRegion;
//# sourceMappingURL=env.js.map